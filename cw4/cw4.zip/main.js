const btn = document.getElementById("btn");

btn.addEventListener("click", async () => {
  await getUser();
});

const getUser = async () => {
  const random = getRandomInt(1, 10);
  const data = await fetch(
    `https://jsonplaceholder.typicode.com/users/${random}`
  );
  const user = await data.json();
  createData(user);
};

const createData = (user) => {
  const placeholder = document.getElementById("placeholder");

  while (placeholder.firstChild) {
    placeholder.removeChild(placeholder.firstChild);
  }
  const userName = document.createElement("div");
  const phoneNumber = document.createElement("div");
  const email = document.createElement("div");

  userName.innerText = user.name;
  phoneNumber.innerText = user.email;
  email.innerText = user.email;

  placeholder.append(userName);
  placeholder.append(phoneNumber);
  placeholder.append(email);
};

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min) + min);
}
